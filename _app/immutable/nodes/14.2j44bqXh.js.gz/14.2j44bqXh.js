import{D as e,F as n}from"../entry/start.DCAA3yTp.js";export{e as component,n as universal};
