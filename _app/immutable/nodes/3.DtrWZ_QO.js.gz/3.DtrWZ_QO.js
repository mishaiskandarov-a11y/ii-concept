import{j as m}from"../entry/start.DCAA3yTp.js";export{m as component};
