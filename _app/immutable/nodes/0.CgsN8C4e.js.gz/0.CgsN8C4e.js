import{_ as e,f as n}from"../entry/start.B-4SWJZM.js";export{e as component,n as universal};
