import{N as e,O as n}from"../entry/start.DCAA3yTp.js";export{e as component,n as universal};
