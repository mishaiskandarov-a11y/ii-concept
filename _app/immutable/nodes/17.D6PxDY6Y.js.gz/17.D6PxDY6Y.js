import{K as m}from"../entry/start.CpLesglQ.js";export{m as component};
