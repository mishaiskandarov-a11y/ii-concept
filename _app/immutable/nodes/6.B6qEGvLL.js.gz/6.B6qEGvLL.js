import{p as e}from"../entry/start.CQbAL8vv.js";export{e as component};
