import{Q as m}from"../entry/start.BxLQqMLe.js";export{m as component};
