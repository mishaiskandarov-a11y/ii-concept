import{R as m}from"../entry/start.DDqBPyBv.js";export{m as component};
