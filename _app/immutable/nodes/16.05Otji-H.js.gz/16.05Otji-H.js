import{I as e,J as n}from"../entry/start.DCAA3yTp.js";export{e as component,n as universal};
