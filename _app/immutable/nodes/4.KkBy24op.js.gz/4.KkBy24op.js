import{k as m}from"../entry/start.ROxdIMnn.js";export{m as component};
