import{R as m}from"../entry/start.CQbAL8vv.js";export{m as component};
